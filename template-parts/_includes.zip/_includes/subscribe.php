
<div class="section section--bg-cyan">
    <h4>Stay Informed</h4>
    <p>Sign up for our newsletter and be the first to know what’s new</p>
    <div class="container p-6">
        <?php 
            echo do_shortcode('[bear_inline]');
        ?>
    </div>
</div>